import * as THREE from 'three';
import { human2, hand, skinMat } from '../body.js';
import { pbr, rng, fbm } from '../pbr.js';
import { tube, loft, mesh, displace, ribbon as ribbonG, merge as mergeG } from '../geo.js';
import { hairMat, hairBaseMat, growHair } from '../hair.js';
import * as TK from '../tex_keyumars.js';

export const frame = { ty: 0.9, dist: 5.3, fov: 24, size: [900, 1300] };
const V3 = THREE.Vector3;

export function build() {
  const g = new THREE.Group(); g.name = 'Keyumars';
  const skin = skinMat('#d6c3b6', { seed: 8, shade: '#b29d90' });
  const body = human2({ skin: '#d6c3b6', mat: skin, spread: 0.0 });
  // drop the stock straight arms: he gets his own (one bent to hold the staff)
  body.children.filter(c => ['Arm', 'Deltoid', 'Hand'].includes(c.name)).forEach(c => body.remove(c));
  g.add(body);

  // ---- tall narrow porous-stone block mask (seated and profile shots): flat slab face,
  //      long block nose stepping out under the brow, small dark eye holes, mouth slit, chin block ----
  const stoneM = pbr({ surf: TK.stoneSurface(), nScale: 1.2, name: 'StoneMask', side: THREE.FrontSide });
  const holeM = pbr({ color: '#0d0b0a', rough: 0.9, name: 'MaskHoles' });
  const MZ = 0.074; // back plane of the mask, in front of the face
  const slab = (w, h, d, x, y, z, rx = 0, p = 7) => {
    const sg = new THREE.SphereGeometry(1, 40, 32), q = sg.attributes.position;
    for (let i = 0; i < q.count; i++) { const X = q.getX(i), Y = q.getY(i), Z = q.getZ(i), k = 1 / Math.pow(Math.abs(X) ** p + Math.abs(Y) ** p + Math.abs(Z) ** p, 1 / p); q.setXYZ(i, X * k * w, Y * k * h, Z * k * d); }
    sg.computeVertexNormals(); const m = mesh(sg, stoneM, 'StoneMask'); m.position.set(x, y, z); m.rotation.x = rx; return m;
  };
  // main slab: 0.12 wide, from the hairline (1.815) to below the chin (1.545), gently convex
  { const m = slab(0.05, 0.13, 0.04, 0, 1.675, MZ + 0.03, -0.03);
    const q = m.geometry.attributes.position; for (let i = 0; i < q.count; i++) { const X = q.getX(i); if (q.getZ(i) > 0) q.setZ(i, q.getZ(i) - 0.008 * (X / 0.05) ** 2); } m.geometry.computeVertexNormals(); g.add(m); }
  // brow ledge across the eyes
  // long block nose: wedge that juts further out toward its flat bottom (Moai-like profile)
  { const ng = new THREE.BoxGeometry(0.036, 0.15, 0.034, 4, 12, 4), q = ng.attributes.position;
    for (let i = 0; i < q.count; i++) { const Y = q.getY(i), t = Math.min(1, Math.max(0, 1 - (Y + 0.075) / 0.15)); if (q.getZ(i) > 0) q.setZ(i, q.getZ(i) + 0.05 * t ** 0.8); q.setX(i, q.getX(i) * (0.9 + 0.2 * t)); }
    { const uv = ng.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * 0.1, uv.getY(i) * 0.4); }
    ng.computeVertexNormals(); const n = mesh(ng, stoneM, 'StoneMaskNose'); n.position.set(0, 1.69, MZ + 0.066); n.rotation.x = -0.02; g.add(n); }
  // small dark eye holes and a mouth slit, set into the slab
  for (const s of [-1, 1]) { const e = mesh(new THREE.CylinderGeometry(0.0075, 0.0075, 0.02, 14), holeM, 'MaskEye'); e.rotation.x = Math.PI / 2; e.position.set(0.026 * s, 1.742, MZ + 0.058); g.add(e); }
  { const mo = mesh(new THREE.BoxGeometry(0.03, 0.006, 0.02), holeM, 'MaskMouth'); mo.position.set(0, 1.603, MZ + 0.066); mo.scale.set(1, 1.6, 1); g.add(mo); }
  // chin block under the mouth
  

  // ---- robe: dark plum boucle knit with dense teal rosettes, ankle length, A-line ----
  const knit = TK.knitSurface([3.6, 5]);
  const knitM = pbr({ surf: knit, sheen: 0.7, sheenColor: '#b0607e', sheenRough: 0.75, nScale: 1.3, name: 'PlumBoucleKnit' });
  const knitS = TK.knitSurface([1.4, 2.2]);
  const knitSM = pbr({ surf: knitS, sheen: 0.7, sheenColor: '#b0607e', sheenRough: 0.75, nScale: 1.3, name: 'PlumBoucleKnitSleeve' });
  const prof = (keys) => t => { for (let i = 0; i < keys.length - 1; i++) { const [t0, v0] = keys[i], [t1, v1] = keys[i + 1]; if (t <= t1) { const k = (t - t0) / (t1 - t0), s = k * k * (3 - 2 * k); return v0 + (v1 - v0) * s; } } return keys[keys.length - 1][1]; };
  const Y = [0.025, 1.54];
  const rx = prof([[0, 0.29], [0.35, 0.235], [0.62, 0.2], [0.82, 0.198], [0.9, 0.205], [0.94, 0.18], [0.975, 0.11], [1, 0.072]]);
  const rz = prof([[0, 0.235], [0.35, 0.175], [0.62, 0.14], [0.82, 0.135], [0.9, 0.13], [0.95, 0.11], [0.98, 0.08], [1, 0.062]]);
  const robe = loft(t => {
    const y = Y[0] + (Y[1] - Y[0]) * t;
    return {
      c: [0, y, 0.005 + 0.025 * Math.max(0, t - 0.75) / 0.25], rx: rx(t), rz: rz(t), p: 2.1,
      f: (a) => {
        let k = 1 + (0.03 * Math.sin(7 * a + 0.4) + 0.018 * Math.sin(13 * a + 1.3) + 0.01 * Math.sin(23 * a)) * Math.max(0, 0.75 - t) / 0.75;
        // rounded old back: a little hump high on the back
        k += 0.07 * Math.max(0, -Math.cos(a)) ** 2 * Math.exp(-(((t - 0.86) / 0.07) ** 2));
        // shoulders: squarer at the sides
        k += 0.05 * Math.abs(Math.sin(a)) ** 4 * Math.exp(-(((t - 0.91) / 0.05) ** 2));
        return k;
      },
      dy: (a) => t < 0.02 ? 0.012 * Math.sin(5 * a + 1) + (Math.cos(a) < 0 ? -0.008 : 0) : 0,
    };
  }, { n: 64, r: 96, uRep: 1 });
  displace(robe, (x, y, z) => 0.004 * (fbm(x * 2 + 0.5, y * 1.5, 4, 3, 7) - 0.5) - 0.0025 * Math.max(0, Math.sin(y * 18 + x * 4)) * (y < 1.1 ? 1 : 0));
  g.add(mesh(robe, knitM, 'Robe'));
  // rolled collar
  { const tor = new THREE.TorusGeometry(0.07, 0.022, 12, 40); const m = mesh(tor, knitSM, 'Collar'); m.rotation.x = Math.PI / 2 + 0.12; m.position.set(0, 1.535, 0.012); m.scale.set(1.15, 1, 1); g.add(m); }

  // ---- arms in long knit sleeves; right hand (model -x) raised and gripping the staff ----
  // the staff path is fixed (seeded), so the grip can wrap around its real surface
  const staffPts = (() => { const r = rng(19), pts = []; for (let i = 0; i <= 14; i++) { const t = i / 14, y = t * 1.86; pts.push([-0.28 + 0.02 * Math.sin(t * 7.5) + (r() - 0.5) * 0.02, y, 0.38 - 0.15 * t + 0.018 * Math.cos(t * 6) + (r() - 0.5) * 0.02]); } return pts; })();
  const staffCv = new THREE.CatmullRomCurve3(staffPts.map(p => new V3(...p)), false, 'catmullrom', 0.5);
  const gripT = 0.6, P = staffCv.getPointAt(gripT), axis = staffCv.getTangentAt(gripT).normalize(), RS = 0.0215;
  const handM = skinMat('#b0948a', { seed: 14, shade: '#957a70', surf: { nStrength: 1.6 } });
  const Eg = new V3(-0.25, 1.16, 0.0);
  const dH = new V3(P.x - Eg.x, 0, P.z - Eg.z).normalize();          // forearm heading (horizontal)
  const lat = new V3(-1, 0, 0);                                       // back of the right hand faces outward
  const Wg = P.clone().sub(dH.clone().multiplyScalar(RS + 0.055)).add(lat.clone().multiplyScalar(0.012)).add(new V3(0, -0.005, 0));
  const arms = [
    { s: 1, S: [0.19, 1.42, -0.005], E: [0.245, 1.14, -0.015], W: [0.262, 0.89, 0.03] },
    { s: -1, S: [-0.19, 1.42, -0.005], E: Eg.toArray(), W: Wg.toArray() },
  ];
  for (const A of arms) {
    const S = new V3(...A.S), E = new V3(...A.E), W = new V3(...A.W);
    const pts = [S.clone().add(new V3(-0.05 * A.s, 0.02, 0)), S, S.clone().lerp(E, 0.5), E, E.clone().lerp(W, 0.5), W];
    g.add(mesh(tube(pts, (t, a) => (0.072 + 0.01 * Math.sin(Math.PI * t) - 0.012 * t) * (1 + 0.04 * Math.sin(a * 5 + t * 8)), { n: 40, r: 24, caps: false }), knitSM, 'Sleeve'));
    const dir = W.clone().sub(E).normalize();
    const cuff = mesh(new THREE.TorusGeometry(0.058, 0.014, 10, 28), knitSM, 'Cuff');
    cuff.position.copy(W.clone().sub(dir.clone().multiplyScalar(0.01))); cuff.quaternion.setFromUnitVectors(new V3(0, 0, 1), dir); g.add(cuff);
    if (A.s > 0) g.add(oldHandHanging(W, dir, A.s, handM));
    else g.add(oldHandGrip(W, P, axis, dH, lat, RS, handM));
  }

  // ---- gnarled pale driftwood staff, taller than him, in the right hand ----
  const woodM = pbr({ surf: TK.driftwoodSurface(), nScale: 1.4, name: 'DriftwoodStaff' });
  {
    const pts = staffPts;
    const knots = [0.18, 0.37, 0.52, 0.71, 0.86];
    const st = tube(pts, (t, a) => {
      let k = 0.017 + 0.005 * (1 - t);
      for (const q of knots) k += 0.008 * Math.exp(-(((t - q) / 0.012) ** 2)) * (0.6 + 0.4 * Math.cos(a * 2 + q * 20));
      return k * (1 + 0.08 * Math.sin(a * 3 + t * 40));
    }, { n: 160, r: 12 });
    g.add(mesh(st, woodM, 'Staff'));
    // forked, broken top
    const top = new V3(...pts[pts.length - 1]);
    g.add(mesh(tube([top.clone().add(new V3(0, -0.06, 0)), top.clone().add(new V3(-0.03, 0.03, 0.01)), top.clone().add(new V3(-0.045, 0.07, 0.0))], t => 0.014 * (1 - 0.6 * t), { n: 10, r: 8 }), woodM, 'StaffFork'));
    g.add(mesh(tube([top.clone().add(new V3(0, -0.03, 0)), top.clone().add(new V3(0.02, 0.04, -0.01))], t => 0.012 * (1 - 0.5 * t), { n: 6, r: 8 }), woodM, 'StaffFork2'));
  }

  // ---- huge shaggy grey-teal hair: spreads over both shoulders, matted clumps, ragged tips at mid-back ----
  const ho = { base: '#93a5a3', light: '#cfdcda', dark: '#5f7172', seed: 61, wave: 0.016, waveF: 4, frizz: 0.05, tipMin: 0.25, count: 1100, wMin: 1.2, wVar: 2.6, lightAmt: 0.55 };
  const hm = hairMat({ ...ho, rough: 0.74, aniso: 0.3, sheen: 0.35, sheenColor: '#d9e6e3', spec: 0.4 });
  const hm2 = hairMat({ ...ho, seed: 66, rough: 0.76, aniso: 0.25, sheen: 0.35, sheenColor: '#d9e6e3', spec: 0.4 });
  const hb = hairBaseMat({ ...ho, rough: 0.78, aniso: 0.3, sheen: 0.3, sheenColor: '#d9e6e3', spec: 0.4 });
  const head = { c: [0, 1.695, -0.004], r: [0.094, 0.128, 0.106] };
  const robeCol = { type: 'zcol', y0: 0.9, y1: 1.5, rx: y => 0.3, rz: y => 0.145 + 0.02 * Math.exp(-(((y - 1.36) / 0.08) ** 2)), cz: -0.0, pad: 0.012 };
  const shoulders = [-1, 1].map(s => ({ c: [0.2 * s, 1.41, -0.01], r: [0.12, 0.075, 0.13], pad: 0.08 }));
  const cols = (hp, sp) => [{ c: head.c, r: head.r, pad: hp }, ...shoulders.map(q => ({ ...q, pad: sp })), robeCol];
  const ragged = (a, r) => (Math.abs(a) > 2.3 ? 1.0 : Math.abs(a) > 1.6 ? 1.06 : 1.16) + r() * 0.2;
  // inner mass
  const H = growHair({
    head, part: 'center', count: 560, azRange: [-Math.PI, Math.PI], skip: a => Math.abs(a) < 0.5,
    departPolar: a => 1.4 + 0.5 * Math.abs(a) / Math.PI, tipY: ragged,
    colliders: cols(0.1, 0.06), side: a => Math.abs(a) < 1.35 ? 1 : -1, pad: 0.1,
    wave: 0.025, waveF: 6, volume: 0.035, flare: 0.05, mat: hm, width: 0.036, seed: 5, taper: 0.6,
  });
  g.add(H.cards);
  // outer shaggy clumps, wider than the shoulder line
  const H2 = growHair({
    head, part: 'center', count: 320, azRange: [-Math.PI, Math.PI], skip: a => Math.abs(a) < 0.62,
    departPolar: a => 1.35 + 0.5 * Math.abs(a) / Math.PI, tipY: (a, r) => ragged(a, r) + 0.03,
    colliders: cols(0.15, 0.1), side: a => Math.abs(a) < 1.5 ? 1 : -1, pad: 0.15,
    wave: 0.035, waveF: 5, volume: 0.05, flare: 0.1, mat: hm2, width: 0.05, seed: 9, taper: 0.75,
  });
  g.add(H2.cards);
  // frizz: thin flyaway wisps over the top of the mass
  const H3 = growHair({
    head, part: 'center', count: 160, azRange: [-Math.PI, Math.PI], skip: a => Math.abs(a) < 0.7,
    departPolar: a => 1.3 + 0.5 * Math.abs(a) / Math.PI, tipY: (a, r) => ragged(a, r) + 0.05,
    colliders: cols(0.2, 0.14), side: a => Math.abs(a) < 1.5 ? 1 : -1, pad: 0.2,
    wave: 0.05, waveF: 8, volume: 0.05, flare: 0.09, mat: hairMat({ ...ho, seed: 71, count: 500, rough: 0.8 }), width: 0.016, seed: 13, taper: 0.8,
  });
  g.add(H3.cards);
  // long grey beard: hangs from under the mask and the jaw line down over the chest
  {
    const bm = hairMat({ ...ho, seed: 81, rootFade: 0.4, tipMin: 0.3, spread: 0.7, count: 900, rough: 0.76, aniso: 0.25, sheen: 0.35, sheenColor: '#d9e6e3', spec: 0.4 });
    const r = rng(23), geos = [];
    for (let i = 0; i < 520; i++) {
      const u = (i + r()) / 520 * 2 - 1;                     // -1..1 across the jaw
      const ang = u * 1.3, rootY = 1.565 + 0.11 * Math.abs(u) ** 1.3 + (r() - 0.2) * 0.05;
      const R0 = new V3(Math.sin(ang) * 0.085, rootY, 0.04 + Math.cos(ang) * 0.06);
      const tip = 1.26 + 0.08 * Math.abs(u) + r() * 0.07;
      const pts = [R0];
      for (let k = 1; k <= 10; k++) {
        const t = k / 10, y = rootY + (tip - rootY) * t;
        const zf = Math.max(0.15 + 0.03 * Math.exp(-(((y - 1.36) / 0.08) ** 2)), 0.12) + 0.012 + 0.02 * r();
        pts.push(new V3(R0.x * (1 + 0.5 * t) + Math.sin(t * 5 + i) * 0.008, y, Math.max(R0.z, zf * Math.cos(ang * 0.6)) + 0.03 * Math.sin(Math.PI * t) * (1 - Math.abs(u))));
      }
      const w = 0.014 * (0.7 + r() * 0.6), u0 = r() * 0.6;
      geos.push(ribbonG(pts, t => w * (1 - 0.4 * t ** 1.4), p => new V3(p.x * 0.6 + (r() - 0.5) * 0.8, 0.05, 1), { n: 20, u0, u1: u0 + 0.3, bow: 0.05, twist: t => (r() - 0.5) * 0.6 }));
    }
    g.add(mesh(mergeG(geos), bm, 'BeardCards'));
  }
  { const hd = body.children.find(c => c.name === 'Head'); if (hd) hd.material = hb; }
  // scalp: crown cap plus the back of the head only (face stays clear)
  { const sg = new THREE.SphereGeometry(1, 32, 12, 0, Math.PI * 2, 0, 0.8); sg.scale(head.r[0] * 1.08, head.r[1] * 1.06, head.r[2] * 1.08); const cap = mesh(sg, hb, 'Scalp'); cap.position.set(...head.c); g.add(cap);
    const bg = new THREE.SphereGeometry(1, 32, 16, Math.PI / 2 + 0.9, Math.PI * 2 - 1.8, 0.7, 1.4); bg.scale(head.r[0] * 1.08, head.r[1] * 1.06, head.r[2] * 1.08); const bk = mesh(bg, hb, 'ScalpBack'); bk.position.set(...head.c); g.add(bk); }

  // ---- dark worn shoes just showing under the hem ----
  const shoeM = pbr({ color: '#1a1614', rough: 0.55, clearcoat: 0.2, name: 'Shoes' });
  for (const s of [-1, 1]) { const sh = mesh(new THREE.SphereGeometry(1, 20, 12), shoeM, 'Shoe'); sh.scale.set(0.05, 0.045, 0.12); sh.position.set(0.095 * s, 0.035, 0.07); g.add(sh); }
  return jpegify(g);
}

// ---- old man's hands: thick fingers that touch, knuckle bulges, a real fist around the staff ----
const prof1 = (keys) => t => { for (let i = 0; i < keys.length - 1; i++) { const [t0, v0] = keys[i], [t1, v1] = keys[i + 1]; if (t <= t1) { const k = (t - t0) / (t1 - t0), q = k * k * (3 - 2 * k); return v0 + (v1 - v0) * q; } } return keys[keys.length - 1][1]; };
const knuckled = (r0, r1) => t => { const base = r0 + (r1 - r0) * t; return base * (1 + 0.12 * Math.exp(-(((t - 0.38) / 0.07) ** 2)) + 0.1 * Math.exp(-(((t - 0.7) / 0.06) ** 2))); };
function finger(pts, r0, r1, m, name = 'Finger') { return mesh(tube(pts, knuckled(r0, r1), { n: 18, r: 12 }), m, name); }
function ellTube(pts, rw, rt, ref, m, name) {
  return mesh(tube(pts, (t, a) => { const c = Math.cos(a), s = Math.sin(a); return 1 / Math.sqrt((c / rw(t)) ** 2 + (s / rt(t)) ** 2); }, { n: 14, r: 18, ref: ref.toArray() }), m, name);
}

function oldHandHanging(W, dir, s, m) {
  const grp = new THREE.Group(); grp.name = 'Hand';
  const inward = new V3(-s, 0, 0);
  const fwd = new V3().crossVectors(inward, dir).normalize(); if (fwd.z < 0) fwd.negate();
  const at = (along, across, inw) => W.clone().add(dir.clone().multiplyScalar(along)).add(fwd.clone().multiplyScalar(across)).add(inward.clone().multiplyScalar(inw));
  // wrist + palm: one tapered elliptical block, wider across the knuckles
  grp.add(ellTube([at(-0.05, 0, 0), at(0.0, 0, 0), at(0.05, 0.002, 0.003), at(0.098, 0.004, 0.006)],
    prof1([[0, 0.027], [0.35, 0.03], [0.75, 0.043], [1, 0.042]]), prof1([[0, 0.022], [0.4, 0.019], [1, 0.015]]), fwd, m, 'Palm'));
  // four thick fingers side by side, gently curled toward the thigh
  const across = [0.031, 0.0105, -0.0105, -0.03], len = [0.078, 0.087, 0.082, 0.066], rad = [0.0108, 0.011, 0.0104, 0.0092];
  for (let f = 0; f < 4; f++) {
    let p = at(0.094, across[f], 0.006), d = dir.clone();
    const pts = [p.clone()];
    const bends = [0.42 + 0.06 * f, 0.62 + 0.05 * f, 0.5];
    for (let k = 0; k < 3; k++) {
      d.applyAxisAngle(fwd, -s * bends[k] * (f === 3 ? 1.15 : 1)); // curl toward the palm side
      p = p.clone().add(d.clone().multiplyScalar(len[f] * [0.45, 0.32, 0.23][k])); pts.push(p.clone());
    }
    grp.add(finger(pts, rad[f], rad[f] * 0.8, m));
  }
  // thumb: from the base of the palm, forward and down, resting against the index finger
  const t0 = at(0.02, 0.036, 0.008);
  grp.add(finger([t0, at(0.05, 0.05, 0.016), at(0.078, 0.047, 0.026), at(0.098, 0.04, 0.032)], 0.0135, 0.0098, m, 'Thumb'));
  return grp;
}

function oldHandGrip(W, P, axis, dH, lat, RS, m) {
  const grp = new THREE.Group(); grp.name = 'Hand';
  const side = new V3().crossVectors(axis, dH).normalize(); if (side.dot(lat) < 0) side.negate(); // lateral (back of hand)
  const dF = new V3().crossVectors(side, axis).normalize(); if (dF.dot(dH) < 0) dF.negate();      // forward
  const ring = (ang, R, h) => P.clone().add(side.clone().multiplyScalar(Math.cos(ang) * R)).add(dF.clone().multiplyScalar(Math.sin(ang) * R)).add(axis.clone().multiplyScalar(h));
  // back of the hand: from the wrist to the knuckle line on the lateral-front of the staff
  const kn = ring(0.35, RS + 0.016, 0.006);
  grp.add(ellTube([W.clone().sub(dH.clone().multiplyScalar(0.035)), W, W.clone().lerp(kn, 0.55), kn],
    prof1([[0, 0.026], [0.3, 0.031], [1, 0.045]]), prof1([[0, 0.021], [0.4, 0.018], [1, 0.016]]), axis, m, 'Palm'));
  // fingers: stacked down the staff, each wrapping round its far side (index on top)
  const hs = [0.031, 0.009, -0.013, -0.032], rr = [0.0112, 0.0118, 0.0109, 0.0095], tilt = [0.004, -0.002, 0.003, -0.004];
  for (let f = 0; f < 4; f++) {
    const R = RS + rr[f] * 0.95, pts = [];
    const a0 = 0.15, a1 = a0 + (f === 3 ? 3.5 : 3.75);
    for (let k = 0; k <= 8; k++) { const a = a0 + (a1 - a0) * k / 8; pts.push(ring(a, R * (1 + 0.15 * Math.max(0, 1 - k / 2)), hs[f] + tilt[f] * Math.sin(k / 8 * Math.PI) - 0.004 * k / 8)); }
    grp.add(finger(pts, rr[f], rr[f] * 0.82, m));
  }
  // thumb: over the top of the index finger, pressing round the inner side
  const tp = [];
  for (let k = 0; k <= 6; k++) { const a = -0.9 - 2.3 * k / 6; tp.push(ring(a, RS + 0.013 + 0.01 * (1 - k / 6), 0.046 - 0.006 * k / 6)); }
  tp.unshift(W.clone().add(axis.clone().multiplyScalar(0.022)).add(side.clone().multiplyScalar(-0.006)));
  grp.add(finger(tp, 0.014, 0.0105, m, 'Thumb'));
  return grp;
}

// smaller GLB: store opaque textures as JPEG (alpha-tested hair/fur maps stay PNG)
function jpegify(root) {
  root.traverse(o => {
    if (!o.isMesh) return;
    const m = o.material;
    for (const k of ['map', 'normalMap', 'roughnessMap', 'metalnessMap']) {
      const t = m[k]; if (!t) continue;
      if (k === 'map' && m.alphaTest > 0) continue;
      t.userData.mimeType = 'image/jpeg';
    }
  });
  return root;
}
